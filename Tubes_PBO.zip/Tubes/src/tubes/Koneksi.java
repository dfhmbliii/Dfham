package tubes;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


/**
 *
 * @author Fadel Adzandika
 */
public class Koneksi {
    private static Connection Koneksi;
    
    public static Connection getKoneksi(){
        if (Koneksi == null){
            try{
            Class.forName("com.mysql.jdbc.Driver");
            Koneksi = DriverManager.getConnection("jdbc:mysql://localhost/kasir_swalayan", "root", "");
            } catch(Exception e){
                System.out.println("Database tidak terKoneksi!");
            } finally{
                System.out.println("");
            }
        }
      return Koneksi;
    }
    
    public static void main(String[] args) {
        Koneksi test = new Koneksi();
        test.getKoneksi();
        System.exit(0);
    }
}